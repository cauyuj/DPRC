//
// Created by yuj on 2020/12/31.
//
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <cmath>
//#include <stdio.h>
//#include <stdlib.h>
#include <cstring>
#include <algorithm>

#include <gsl_permute.h>
#include <gsl_permutation.h>

#include "gsl_rng.h"
#include "gsl_linalg.h"
#include "gsl_blas.h"
#include "gsl_eigen.h"
#include "gsl_randist.h"
#include "gsl_cdf.h"
#include "gsl_roots.h"
#include "gsl_matrix.h"
#include "gsl_vector.h"
#include "Eigen/Dense"

using namespace std;
using namespace Eigen;

double sum_Elogvl2(const VectorXd vk, size_t k) {
    double sumElogvl = 0;
    if (k==0) sumElogvl = 0;
    else {
        for (size_t j = 0; j<k; j++)	{
            sumElogvl += log(1-vk(j));
        }
    }
    return sumElogvl;
}

VectorXd permute(size_t nSNP)  {
    VectorXd snp_label (nSNP);
    long int randseed;
    gsl_rng *gsl_r;
    time_t rawtime;
    time (&rawtime);
    tm * ptm = gmtime (&rawtime);
    randseed = (unsigned) (ptm->tm_hour%24*3600+ptm->tm_min*60+ptm->tm_sec);
    const gsl_rng_type * gslType;
    gslType = gsl_rng_default;
    gsl_r = gsl_rng_alloc(gslType);
    gsl_rng_set(gsl_r, randseed);
    gsl_permutation * perm = gsl_permutation_alloc (nSNP);
    gsl_permutation_init (perm);
    gsl_ran_shuffle (gsl_r, perm->data, nSNP, sizeof(size_t));
    for (size_t i = 0; i<nSNP; i++)	{
        snp_label(i) = perm->data[i];
    }
    return snp_label;
}

double sum_lambda_k(const MatrixXd pik_beta, size_t k, size_t n_k) {
    double slambda_k =0;
    if ((k+1)>(n_k-1)) {slambda_k =0;}
    else {
        for (size_t j=k+1; j<n_k-1; j++) {
            slambda_k += pik_beta.col(j).sum();
        }
    }
    return slambda_k;
}


void DPRC (const MatrixXd X, const VectorXd Y, const MatrixXd W) {
    setprecision(6);
    clock_t time_begin = clock();
    size_t nSNP = X.cols();
    size_t n_j = W.cols();
    size_t nID = Y.size();
    size_t w_step = 20000;
    size_t s_step = 10000;
    double tp = 0.1;
    double sp = 0.1;

    VectorXd x_col(nSNP);
    VectorXd xtx(nSNP);
    VectorXd xty(nSNP);
    VectorXd wtw(n_j);
    VectorXd wty(n_j);
    VectorXd U = VectorXd::Zero(nID);
    VectorXd Ue(nID);
    VectorXd Ub(nID);
//定义截距和V，M？nSNP
    VectorXd Beta=VectorXd::Random(nSNP);
    MatrixXd D = MatrixXd::Random(nID, nSNP);
    VectorXd WBeta = VectorXd::Random(nID);
    VectorXd se_WBeta = VectorXd::Random(nID);
    VectorXd bv0 = VectorXd::Zero(nID);
    VectorXd bv = VectorXd::Zero(nID);
    VectorXd V = VectorXd::Zero(nID);
    VectorXd M = VectorXd::Zero(nID);
    VectorXd snp_label(nSNP);
    VectorXd Ealpha = WBeta;
    VectorXd post_Ealpha = VectorXd::Zero(n_j);
    VectorXd m_alpha = WBeta;
    VectorXd s2_alpha = se_WBeta.array() * se_WBeta.array();
    double lambda;
    VectorXd WEalpha(nID);
    double sigma2e = 0, lambdax;
    VectorXd XEbeta(nID); //G*beta
    VectorXd Ebeta(nSNP);
    VectorXd post_Ebeta(nSNP);//save beta
    MatrixXd Ebeta2k;
    MatrixXd B1;
    int n_k = 4;
    MatrixXd mik_beta = MatrixXd::Zero(nSNP, n_k);

    for (size_t i = 0; i < nSNP; i++) {
        x_col = X.col(i);   //X and x
        xtx(i) = x_col.dot(x_col);
        xty(i) = x_col.dot(Y);
    }

    for (size_t j = 0; j < n_j; j++) {
        wtw(j) = W.col(j).dot(W.col(j));
        wty(j) = W.col(j).dot(Y);
    }

    //初始化每个SNP和正态组分的值
    //假设开始时每个正态组分有一样的值
    for (size_t i = 0; i < nSNP; i++) {
        for (size_t k = 1; k < n_k; k++) {
            mik_beta(i, k) = Beta(i);
        }
    }
    mik_beta.col(0).fill(0);
    MatrixXd sik2_beta = (MatrixXd::Random(nSNP, n_k)).array().abs();
    MatrixXd pik_beta = MatrixXd::Zero(nSNP, n_k);
    pik_beta = pik_beta.array() + (double) 1 / n_k;

    MatrixXd beta_beta = MatrixXd::Zero(nSNP, n_k);
    MatrixXd gamma_beta = MatrixXd::Zero(nSNP, n_k);
    MatrixXd post_gamma_beta = gamma_beta;
    gamma_beta = gamma_beta.array() + (double) 1 / n_k;
////

    VectorXd sigma2k(n_k);
    VectorXd Vk(n_k);
    VectorXd Elogsigmak(n_k);
    VectorXd ElogVk(n_k);
    VectorXd sumElogVl(n_k);

    VectorXd pikexp1(n_k);
    VectorXd pikexp2(n_k);
    VectorXd index;
    VectorXd a_k = (VectorXd::Random(n_k)).array().abs();
    VectorXd b_k = (VectorXd::Random(n_k)).array().abs();
    VectorXd lambda_k = (VectorXd::Random(n_k)).array().abs();
    VectorXd kappa_k = pik_beta.colwise().sum();

    XEbeta.setZero();
    for (size_t i = 0; i < nSNP; i++) {
        x_col = X.col(i);
        XEbeta += x_col * Beta(i);
    }

    WEalpha.setZero();
    for (size_t j = 0; j < n_j; j++) {
        WEalpha += W.col(j) * m_alpha(j);
    }

    VectorXd y_res = Y - WEalpha - XEbeta;
    double sigma2e0 = (y_res).dot(y_res) / (nID - 1);
    cout << endl << endl;
    double a_e = (double) (2 * nID + nSNP) / 2;
    double b_e = (a_e - 1) * sigma2e0;

    double ak = 21;
    double lambda1 = 0.01;
    double lambda2 = 0.01;
    double lambda3 = 0.01;
    double lambda4 = 0.01;
    //
    if (lambda < 0.01) { lambda = 0.01; }
    else if (lambda > 100) { lambda = 100; }
    else { lambda = lambda; }

    double bk0 = lambda * (ak - 1) / nSNP;

    VectorXd bk(n_k);
    bk(0) = bk0;
    for (size_t i = 1; i < n_k; i++) {
        bk(i) = bk(i - 1) * 1.7 * sqrt(pow(i, i));
    }

    for (size_t i = 0; i < nSNP; i++) {
        for (size_t k = 0; k < n_k; k++) {
            sik2_beta(i, k) = bk(k) / (ak - 1) * sigma2e0;
        }
    }

    double ae = 0.1;
    double be = 0.1;
    double a0 = 400;
    double b0 = 40;
    double a_lambda = a0 + n_k;
    double b_lambda = b0;
    double Elogsigmae, tx_ywx_res, xtxabk, A, post_Gn = 0;
    double sigma2b = 0.001;

    ///initial values for a_k, b_k, sigma2k
    Ebeta2k = (mik_beta.cwiseProduct(mik_beta)) + sik2_beta;
    for (size_t k = 0; k < n_k; k++) {
        a_k(k) = (pik_beta.col(k).sum()) / 2 + ak;
        b_k(k) = (Ebeta2k.col(k).sum()) * (a_e / b_e) / 2 + bk(k);
        sigma2k(k) = b_k(k) / (a_k(k) - 1);
    }
    A = (y_res).dot(y_res);
    B1 = (1 / sigma2k.array()).rowwise().replicate(nSNP);
    B1.col(0).fill(0);

    Ebeta2k = Ebeta2k.cwiseProduct(B1.transpose());
    double B = Ebeta2k.sum();
    a_e = nID + nSNP * 0.1 + ae;
    b_e = (A + B + 2 * be) / 2;
    ///random seed
    gsl_rng *rs = gsl_rng_alloc(gsl_rng_mt19937);


    ///begin MCMC sampling
    for (size_t S = 0; S < (w_step + s_step); S++) {

        sigma2e = 1 / gsl_ran_gamma(rs, a_e, 1 / b_e);
        Elogsigmae = log(sqrt(sigma2e));

        Ebeta = (beta_beta.cwiseProduct(gamma_beta)).rowwise().sum();

        if (S > (w_step - 1)) {
            post_Ebeta += Ebeta;
        }
//Class C mixed distribution
        for (size_t k = 0; k < n_k; k++) {
            if (k == 1) {
                sigma2k(k) = 0;
                Elogsigmak(k) = 0;
            } else {
                sigma2k(k) = 1 / gsl_ran_gamma(rs, a_k(k), 1 / b_k(k));
                Elogsigmak(k) = log(sqrt(sigma2k(k)));
            }
            if (k == (n_k - 1)) {
                Vk(k) = 0;
                ElogVk(k) = 0;
            } else {
                Vk(k) = gsl_ran_beta(rs, kappa_k(k), lambda_k(k));
                ElogVk(k) = log(Vk(k));
            }
            sumElogVl(k) = sum_Elogvl2(Vk, k);
        }


        XEbeta.setZero();
        for (size_t i = 0; i < nSNP; i++) {
            x_col = X.col(i);
            XEbeta += x_col * Ebeta(i);
        }

        y_res.setZero();
            y_res = Y - WEalpha - U;

            if (S < (w_step + s_step) * tp) {
                for (size_t i = 0; i < nSNP; i++) {
                    x_col = X.col(i);
                    XEbeta -= x_col * Ebeta(i);
                    tx_ywx_res = x_col.dot(y_res - XEbeta);
                    for (size_t k = 0; k < n_k; k++) {
                        if (k == 0) {
                            mik_beta(i, k) = 0;
                            sik2_beta(i, k) = 0;
                            pikexp1(k) = 0;
                        } else {
                            xtxabk = xtx(i) + 1 / sigma2k(k);
                            mik_beta(i, k) = tx_ywx_res / xtxabk;
                            sik2_beta(i, k) = sigma2e / xtxabk;
                            pikexp1(k) = mik_beta(i, k) * mik_beta(i, k) / (2 * sik2_beta(i, k)) +
                                         log(sqrt(sik2_beta(i, k))) - Elogsigmae - Elogsigmak(k);
                        }
                        beta_beta(i, k) = gsl_ran_gaussian(rs, sqrt(sik2_beta(i, k))) + mik_beta(i, k);
                        pikexp2(k) = ElogVk(k) + sumElogVl(k);
                    }
                    index = pikexp1 + pikexp2;
                    index = (index.array() - index.maxCoeff()).exp();
                    pik_beta.row(i) = index / index.sum();


                    double mult_prob[n_k];
                    unsigned int mult_no[n_k];
                    for (size_t k = 0; k < n_k; k++) {
                        mult_prob[k] = pik_beta(i, k);
                    }
                    gsl_ran_multinomial(rs, n_k, 1, mult_prob, mult_no);
                    for (size_t k = 0; k < n_k; k++) {
                        gamma_beta(i, k) = mult_no[k];
                    }
                    Ebeta(i) = (beta_beta.row(i)).dot(gamma_beta.row(i));
                    XEbeta += x_col * Ebeta(i);
                }
            }
            else {
                snp_label = permute(nSNP);
                size_t i, non_zero = 0, j = 0, T0 = nSNP * sp + 1;
                while (j < T0) {
                    i = snp_label(j);
                    x_col = X.col(i);
                    XEbeta -= x_col * Ebeta(i);
                    tx_ywx_res = x_col.dot(y_res - XEbeta);
                    for (size_t k = 0; k < n_k; k++) {
                        if (k == 0) {
                            mik_beta(i, k) = 0;
                            sik2_beta(i, k) = 0;
                            pikexp1(k) = 0;
                        } else {
                            xtxabk = xtx(i) + 1 / sigma2k(i);
                            mik_beta(i, k) = tx_ywx_res / xtxabk;
                            sik2_beta(i, k) = sigma2e / xtxabk;
                            pikexp1(k) = mik_beta(i, k) * mik_beta(i, k) / (2 * sik2_beta(i, k)) +
                                         log(sqrt(sik2_beta(i, k))) - Elogsigmae - Elogsigmak(k);
                        }
                        beta_beta(i, k) = gsl_ran_gaussian(rs, sqrt(sik2_beta(i, k))) + mik_beta(i, k);
                        pikexp2(k) = ElogVk(k) + sumElogVl(k);
                    }
                    index = pikexp1 + pikexp2;
                    index = (index.array() - index.maxCoeff()).exp();
                    pik_beta.row(i) = index / index.sum();

                    ///multinomial sampling
                    double mult_prob[n_k];
                    unsigned int mult_no[n_k];
                    for (size_t k = 0; k < n_k; k++) {
                        mult_prob[k] = pik_beta(i, k);
                    }
                    gsl_ran_multinomial(rs, n_k, 1, mult_prob, mult_no);
                    for (size_t k = 0; k < n_k; k++) {
                        gamma_beta(i, k) = mult_no[k];
                    }
                    non_zero += gamma_beta.row(i).tail(n_k - 1).sum();
                    Ebeta(i) = ((beta_beta.row(i)).dot(gamma_beta.row(i)));
                    XEbeta += x_col * Ebeta(i);
                    j++;
                }
            }

            if (S > (w_step - 1)) {
                post_gamma_beta += gamma_beta;
            }

            WEalpha.setZero();
            for (size_t j = 0; j < n_j; j++) {
                WEalpha += W.col(j) * Ealpha(j);
            }

            y_res.setZero();
            y_res = Y - XEbeta - U;
            for (size_t j = 0; j < n_j; j++) {
                WEalpha -= W.col(j) * Ealpha(j);
                m_alpha(j) = 1 / wtw(j) * (W.col(j).dot(y_res - WEalpha));
                s2_alpha(j) = sigma2e / wtw(j);
                Ealpha(j) = m_alpha(j) + gsl_ran_gaussian(rs, sqrt(s2_alpha(j)));
                W.col(j) * Ealpha(j);
            }

            if (S > (w_step - 1)) {
                post_Ealpha += Ealpha;
            }

            a_lambda = a0 + n_k;
            b_lambda = b0 - sum_Elogvl2(Vk, n_k - 1);
            lambdax = gsl_ran_gamma(rs, a_lambda, 1 / b_lambda);

            for (size_t k = 0; k < n_k; k++) {
                kappa_k(k) = gamma_beta.col(k).sum() + 1;
                lambda_k(k) = sum_lambda_k(gamma_beta, k, n_k) + lambdax;
            }

            Ebeta2k = beta_beta.cwiseProduct(beta_beta).cwiseProduct(gamma_beta);
            for (size_t k = 0; k < n_k; k++) {
                a_k(k) = (gamma_beta.col(k).sum()) / 2 + ak;
                b_k(k) = (Ebeta2k.col(k).sum()) / (2 * sigma2e) + bk(k);
            }

            y_res.setZero();
            y_res = Y - XEbeta - WEalpha;
            for (size_t n = 0; n < nSNP; n++) {
                V(n) = sigma2b * D(n) / (sigma2b * D(n) + 1);
                M(n) = y_res(n) * V(n);
                U(n) = M(n) + gsl_ran_gaussian(rs, sqrt(V(n) * sigma2e));
                if (D(n) == 0) {
                    Ue(n) = 0;
                    Ub(n) = 0;
                } else {
                    Ue(n) = U(n) / (sigma2b * D(n));
                    Ub(n) = U(n) / (sigma2e * D(n));
                }
                bv0(n) = y_res(n) * sigma2b / (sigma2b * D(n) + 1);
            }

            if (S > (w_step - 1)) { bv += bv0; }

            A = (y_res - U).dot(y_res - U);
            B1 = (1 / sigma2k.tail(n_k - 1).array()).rowwise().replicate(nSNP);
            Ebeta2k = Ebeta2k.rightCols(n_k - 1).cwiseProduct(B1.transpose());
            double B = Ebeta2k.sum();
            double Gn = gamma_beta.rightCols(n_k - 1).sum();

            a_e = nID + Gn / 2 + ae;
            b_e = (A + B + Ue.dot(U) + 2 * be) / 2;
            sigma2b = 1 / gsl_ran_gamma(rs, nID / 2 + ae, 1 / (2 * Ub.dot(U)) + be);

            if (S > (w_step - 1)) { post_Gn += Gn; }

            size_t xstep = (s_step + w_step) * 0.01 + 1;
            if (S % xstep == 0 || S == (s_step + w_step - 1)) {//ProgressBar("MCMC sampling ",S,s_step + w_step -1);}
            }
        }

        mixture_no = post_Gn / s_step;
        cout << endl << endl << "MCMC sampling is finished and now compute the polygenic effects ..." << endl;
        VectorXd eigen_alpha = VectorXd::Zero(nSNP);
        eigen_alpha = X.transpose() * (bv / s_step) / nSNP;
        WriteCoeff(eigen_alpha, post_Ebeta / s_step);
        pheno_mean = post_Ealpha(0) / s_step;
        cout << endl << "Computaion Time for DPRC.Gibbs = ";
        cout << (clock() - time_begin) / (double(CLOCKS_PER_SEC) * 60.0) << " min" << endl << endl;


        xtx.resize(0);
        xty.resize(0);
        wtw.resize(0);
        wty.resize(0);
        U.resize(0);
        Ue.resize(0);
        Ub.resize(0);
        bv0.resize(0);
        bv.resize(0);
        V.resize(0);
        M.resize(0);
        Ealpha.resize(0);
        post_Ealpha.resize(0);
        m_alpha.resize(0);
        s2_alpha.resize(0);
        WEalpha.resize(0);
        XEbeta.resize(0);
        Ebeta.resize(0);
        post_Ebeta.resize(0);
        Ebeta2k.resize(0, 0);
        B1.resize(0, 0);
        mik_beta.resize(0, 0);
        sik2_beta.resize(0, 0);
        pik_beta.resize(0, 0);
        beta_beta.resize(0, 0);
        gamma_beta.resize(0, 0);
        sigma2k.resize(0);
        Vk.resize(0);
        Elogsigmak.resize(0);
        ElogVk.resize(0);
        sumElogVl.resize(0);
        pikexp1.resize(0);
        pikexp2.resize(0);
        index.resize(0);
        a_k.resize(0);
        b_k.resize(0);
        kappa_k.resize(0);
        lambda_k.resize(0);
        y_res.resize(0);
        bk.resize(0);
        eigen_alpha.resize(0);
}





void DPRC_AS (const MatrixXd X, const VectorXd Y, const MatrixXd W) {
    setprecision(6);
    clock_t time_begin = clock();
    size_t nSNP = X.cols();
    size_t n_j = W.cols();
    size_t nID = Y.size();
    size_t w_step = 20000;
    size_t s_step = 10000;
    double tp = 0.1;
    double sp = 0.1;

    VectorXd x_col(nSNP);
    VectorXd xtx(nSNP);
    VectorXd xty(nSNP);
    VectorXd wtw(n_j);
    VectorXd wty(n_j);
    VectorXd U = VectorXd::Zero(nID);
    VectorXd Ue(nID);
    VectorXd Ub(nID);
//定义截距和V，M？nSNP
    VectorXd Beta=VectorXd::Random(nSNP);
    MatrixXd D = MatrixXd::Random(nID, nSNP);
    VectorXd WBeta = VectorXd::Random(nID);
    VectorXd se_WBeta = VectorXd::Random(nID);
    VectorXd bv0 = VectorXd::Zero(nID);
    VectorXd bv = VectorXd::Zero(nID);
    VectorXd V = VectorXd::Zero(nID);
    VectorXd M = VectorXd::Zero(nID);
    VectorXd snp_label(nSNP);
    VectorXd Ealpha = WBeta;
    VectorXd post_Ealpha = VectorXd::Zero(n_j);
    VectorXd m_alpha = WBeta;
    VectorXd s2_alpha = se_WBeta.array() * se_WBeta.array();
    double lambda;
    VectorXd WEalpha(nID);
    double sigma2e = 0, lambdax;
    VectorXd XEbeta(nID); //G*beta
    VectorXd Ebeta(nSNP);
    VectorXd post_Ebeta(nSNP);//save beta
    MatrixXd Ebeta2k;
    MatrixXd B1;
    int n_k = 4;
    MatrixXd mik_beta = MatrixXd::Zero(nSNP, n_k);

    for (size_t i = 0; i < nSNP; i++) {
        x_col = X.col(i);   //X and x
        xtx(i) = x_col.dot(x_col);
        xty(i) = x_col.dot(Y);
    }

    for (size_t j = 0; j < n_j; j++) {
        wtw(j) = W.col(j).dot(W.col(j));
        wty(j) = W.col(j).dot(Y);
    }

    //初始化每个SNP和正态组分的值
    //假设开始时每个正态组分有一样的值
    for (size_t i = 0; i < nSNP; i++) {
        for (size_t k = 1; k < n_k; k++) {
            mik_beta(i, k) = Beta(i);
        }
    }
    mik_beta.col(0).fill(0);
    MatrixXd sik2_beta = (MatrixXd::Random(nSNP, n_k)).array().abs();
    MatrixXd pik_beta = MatrixXd::Zero(nSNP, n_k);
    pik_beta = pik_beta.array() + (double) 1 / n_k;

    MatrixXd beta_beta = MatrixXd::Zero(nSNP, n_k);
    MatrixXd gamma_beta = MatrixXd::Zero(nSNP, n_k);
    MatrixXd post_gamma_beta = gamma_beta;
    gamma_beta = gamma_beta.array() + (double) 1 / n_k;
////

    VectorXd sigma2k(n_k);
    VectorXd Vk(n_k);
    VectorXd Elogsigmak(n_k);
    VectorXd ElogVk(n_k);
    VectorXd sumElogVl(n_k);

    VectorXd pikexp1(n_k);
    VectorXd pikexp2(n_k);
    VectorXd index;
    VectorXd a_k = (VectorXd::Random(n_k)).array().abs();
    VectorXd b_k = (VectorXd::Random(n_k)).array().abs();
    VectorXd lambda_k = (VectorXd::Random(n_k)).array().abs();
    VectorXd kappa_k = pik_beta.colwise().sum();

    XEbeta.setZero();
    for (size_t i = 0; i < nSNP; i++) {
        x_col = X.col(i);
        XEbeta += x_col * Beta(i);
    }

    WEalpha.setZero();
    for (size_t j = 0; j < n_j; j++) {
        WEalpha += W.col(j) * m_alpha(j);
    }

    VectorXd y_res = Y - WEalpha - XEbeta;
    double sigma2e0 = (y_res).dot(y_res) / (nID - 1);
    cout << endl << endl;
    double a_e = (double) (2 * nID + nSNP) / 2;
    double b_e = (a_e - 1) * sigma2e0;

    double ak = 21;
    double lambda1 = 0.01;
    double lambda2 = 0.01;
    double lambda3 = 0.01;
    double lambda4 = 0.01;
    //
    if (lambda < 0.01) { lambda = 0.01; }
    else if (lambda > 100) { lambda = 100; }
    else { lambda = lambda; }

    double bk0 = lambda * (ak - 1) / nSNP;

    VectorXd bk(n_k);
    bk(0) = bk0;
    for (size_t i = 1; i < n_k; i++) {
        bk(i) = bk(i - 1) * 1.7 * sqrt(pow(i, i));
    }

    for (size_t i = 0; i < nSNP; i++) {
        for (size_t k = 0; k < n_k; k++) {
            sik2_beta(i, k) = bk(k) / (ak - 1) * sigma2e0;
        }
    }

    double ae = 0.1;
    double be = 0.1;
    double a0 = 400;
    double b0 = 40;
    double a_lambda = a0 + n_k;
    double b_lambda = b0;
    double Elogsigmae, tx_ywx_res, xtxabk, A, post_Gn = 0;
    double sigma2b = 0.001;

    ///initial values for a_k, b_k, sigma2k
    Ebeta2k = (mik_beta.cwiseProduct(mik_beta)) + sik2_beta;
    for (size_t k = 0; k < n_k; k++) {
        a_k(k) = (pik_beta.col(k).sum()) / 2 + ak;
        b_k(k) = (Ebeta2k.col(k).sum()) * (a_e / b_e) / 2 + bk(k);
        sigma2k(k) = b_k(k) / (a_k(k) - 1);
    }
    A = (y_res).dot(y_res);
    B1 = (1 / sigma2k.array()).rowwise().replicate(nSNP);
    B1.col(0).fill(0);

    Ebeta2k = Ebeta2k.cwiseProduct(B1.transpose());
    double B = Ebeta2k.sum();
    a_e = nID + nSNP * 0.1 + ae;
    b_e = (A + B + 2 * be) / 2;
    ///random seed
    gsl_rng *rs = gsl_rng_alloc(gsl_rng_mt19937);


    ///begin MCMC sampling
    for (size_t S = 0; S < (w_step + s_step); S++) {

        sigma2e = 1 / gsl_ran_gamma(rs, a_e, 1 / b_e);
        Elogsigmae = log(sqrt(sigma2e));

        Ebeta = (beta_beta.cwiseProduct(gamma_beta)).rowwise().sum();

        if (S > (w_step - 1)) {
            post_Ebeta += Ebeta;
        }
//Class C mixed distribution
        for (size_t k = 0; k < n_k; k++) {
            if (k == 1) {
                sigma2k(k) = 0;
                Elogsigmak(k) = 0;
            } else {
                sigma2k(k) = 1 / gsl_ran_gamma(rs, a_k(k), 1 / b_k(k));
                Elogsigmak(k) = log(sqrt(sigma2k(k)));
            }
            if (k == (n_k - 1)) {
                Vk(k) = 0;
                ElogVk(k) = 0;
            } else {
                Vk(k) = gsl_ran_beta(rs, kappa_k(k), lambda_k(k));
                ElogVk(k) = log(Vk(k));
            }
            sumElogVl(k) = sum_Elogvl2(Vk, k);
        }


        XEbeta.setZero();
        for (size_t i = 0; i < nSNP; i++) {
            x_col = X.col(i);
            XEbeta += x_col * Ebeta(i);
        }

        y_res.setZero();
            y_res = Y - WEalpha - U;

            if (S < (w_step + s_step) * tp) {
                for (size_t i = 0; i < nSNP; i++) {
                    x_col = X.col(i);
                    XEbeta -= x_col * Ebeta(i);
                    tx_ywx_res = x_col.dot(y_res - XEbeta);
                    for (size_t k = 0; k < n_k; k++) {
                        if (k == 0) {
                            mik_beta(i, k) = 0;
                            sik2_beta(i, k) = 0;
                            pikexp1(k) = 0;
                        } else {
                            xtxabk = xtx(i) + 1 / sigma2k(k);
                            mik_beta(i, k) = tx_ywx_res / xtxabk;
                            sik2_beta(i, k) = sigma2e / xtxabk;
                            pikexp1(k) = mik_beta(i, k) * mik_beta(i, k) / (2 * sik2_beta(i, k)) +
                                         log(sqrt(sik2_beta(i, k))) - Elogsigmae - Elogsigmak(k);
                        }
                        beta_beta(i, k) = gsl_ran_gaussian(rs, sqrt(sik2_beta(i, k))) + mik_beta(i, k);
                        pikexp2(k) = ElogVk(k) + sumElogVl(k);
                    }
                    index = pikexp1 + pikexp2;
                    index = (index.array() - index.maxCoeff()).exp();
                    pik_beta.row(i) = index / index.sum();


                    double mult_prob[n_k];
                    unsigned int mult_no[n_k];
                    for (size_t k = 0; k < n_k; k++) {
                        mult_prob[k] = pik_beta(i, k);
                    }
                    gsl_ran_multinomial(rs, n_k, 1, mult_prob, mult_no);
                    for (size_t k = 0; k < n_k; k++) {
                        gamma_beta(i, k) = mult_no[k];
                    }
                    Ebeta(i) = (beta_beta.row(i)).dot(gamma_beta.row(i));
                    XEbeta += x_col * Ebeta(i);
                }
            }
            else {
                snp_label = permute(nSNP);
                size_t i, non_zero = 0, j = 0, T0 = nSNP * sp + 1;
                while (j < T0) {
                    i = snp_label(j);
                    x_col = X.col(i);
                    XEbeta -= x_col * Ebeta(i);
                    tx_ywx_res = x_col.dot(y_res - XEbeta);
                    for (size_t k = 0; k < n_k; k++) {
                        if (k == 0) {
                            mik_beta(i, k) = 0;
                            sik2_beta(i, k) = 0;
                            pikexp1(k) = 0;
                        } else {
                            xtxabk = xtx(i) + 1 / sigma2k(i);
                            mik_beta(i, k) = tx_ywx_res / xtxabk;
                            sik2_beta(i, k) = sigma2e / xtxabk;
                            pikexp1(k) = mik_beta(i, k) * mik_beta(i, k) / (2 * sik2_beta(i, k)) +
                                         log(sqrt(sik2_beta(i, k))) - Elogsigmae - Elogsigmak(k);
                        }
                        beta_beta(i, k) = gsl_ran_gaussian(rs, sqrt(sik2_beta(i, k))) + mik_beta(i, k);
                        pikexp2(k) = ElogVk(k) + sumElogVl(k);
                    }
                    index = pikexp1 + pikexp2;
                    index = (index.array() - index.maxCoeff()).exp();
                    pik_beta.row(i) = index / index.sum();

                    ///multinomial sampling
                    double mult_prob[n_k];
                    unsigned int mult_no[n_k];
                    for (size_t k = 0; k < n_k; k++) {
                        mult_prob[k] = pik_beta(i, k);
                    }
                    gsl_ran_multinomial(rs, n_k, 1, mult_prob, mult_no);
                    for (size_t k = 0; k < n_k; k++) {
                        gamma_beta(i, k) = mult_no[k];
                    }
                    non_zero += gamma_beta.row(i).tail(n_k - 1).sum();
                    Ebeta(i) = ((beta_beta.row(i)).dot(gamma_beta.row(i)));
                    XEbeta += x_col * Ebeta(i);
                    j++;
                }
            }

            if (S > (w_step - 1)) {
                post_gamma_beta += gamma_beta;
            }

            WEalpha.setZero();
            for (size_t j = 0; j < n_j; j++) {
                WEalpha += W.col(j) * Ealpha(j);
            }

            y_res.setZero();
            y_res = Y - XEbeta - U;
            for (size_t j = 0; j < n_j; j++) {
                WEalpha -= W.col(j) * Ealpha(j);
                m_alpha(j) = 1 / wtw(j) * (W.col(j).dot(y_res - WEalpha));
                s2_alpha(j) = sigma2e / wtw(j);
                Ealpha(j) = m_alpha(j) + gsl_ran_gaussian(rs, sqrt(s2_alpha(j)));
                W.col(j) * Ealpha(j);
            }

            if (S > (w_step - 1)) {
                post_Ealpha += Ealpha;
            }

            a_lambda = a0 + n_k;
            b_lambda = b0 - sum_Elogvl2(Vk, n_k - 1);
            lambdax = gsl_ran_gamma(rs, a_lambda, 1 / b_lambda);

            for (size_t k = 0; k < n_k; k++) {
                kappa_k(k) = gamma_beta.col(k).sum() + 1;
                lambda_k(k) = sum_lambda_k(gamma_beta, k, n_k) + lambdax;
            }

            Ebeta2k = beta_beta.cwiseProduct(beta_beta).cwiseProduct(gamma_beta);
            for (size_t k = 0; k < n_k; k++) {
                a_k(k) = (gamma_beta.col(k).sum()) / 2 + ak;
                b_k(k) = (Ebeta2k.col(k).sum()) / (2 * sigma2e) + bk(k);
            }

            y_res.setZero();
            y_res = Y - XEbeta - WEalpha;
            for (size_t n = 0; n < nSNP; n++) {
                V(n) = sigma2b * D(n) / (sigma2b * D(n) + 1);
                M(n) = y_res(n) * V(n);
                U(n) = M(n) + gsl_ran_gaussian(rs, sqrt(V(n) * sigma2e));
                if (D(n) == 0) {
                    Ue(n) = 0;
                    Ub(n) = 0;
                } else {
                    Ue(n) = U(n) / (sigma2b * D(n));
                    Ub(n) = U(n) / (sigma2e * D(n));
                }
                bv0(n) = y_res(n) * sigma2b / (sigma2b * D(n) + 1);
            }

            if (S > (w_step - 1)) { bv += bv0; }

            A = (y_res - U).dot(y_res - U);
            B1 = (1 / sigma2k.tail(n_k - 1).array()).rowwise().replicate(nSNP);
            Ebeta2k = Ebeta2k.rightCols(n_k - 1).cwiseProduct(B1.transpose());
            double B = Ebeta2k.sum();
            double Gn = gamma_beta.rightCols(n_k - 1).sum();

            a_e = nID + Gn / 2 + ae;
            b_e = (A + B + Ue.dot(U) + 2 * be) / 2;
            sigma2b = 1 / gsl_ran_gamma(rs, nID / 2 + ae, 1 / (2 * Ub.dot(U)) + be);

            if (S > (w_step - 1)) { post_Gn += Gn; }

            size_t xstep = (s_step + w_step) * 0.01 + 1;
            if (S % xstep == 0 || S == (s_step + w_step - 1)) {//ProgressBar("MCMC sampling ",S,s_step + w_step -1);}
            }
        }

        mixture_no = post_Gn / s_step;
        cout << endl << endl << "MCMC sampling is finished and now compute the polygenic effects ..." << endl;
        VectorXd eigen_alpha = VectorXd::Zero(nSNP);
        eigen_alpha = X.transpose() * (bv / s_step) / nSNP;
        WriteCoeff(eigen_alpha, post_Ebeta / s_step);
        pheno_mean = post_Ealpha(0) / s_step;
        cout << endl << "Computaion Time for DPRC_AS.Gibbs = ";
        cout << (clock() - time_begin) / (double(CLOCKS_PER_SEC) * 60.0) << " min" << endl << endl;


        xtx.resize(0);
        xty.resize(0);
        wtw.resize(0);
        wty.resize(0);
        U.resize(0);
        Ue.resize(0);
        Ub.resize(0);
        bv0.resize(0);
        bv.resize(0);
        V.resize(0);
        M.resize(0);
        Ealpha.resize(0);
        post_Ealpha.resize(0);
        m_alpha.resize(0);
        s2_alpha.resize(0);
        WEalpha.resize(0);
        XEbeta.resize(0);
        Ebeta.resize(0);
        post_Ebeta.resize(0);
        Ebeta2k.resize(0, 0);
        B1.resize(0, 0);
        mik_beta.resize(0, 0);
        sik2_beta.resize(0, 0);
        pik_beta.resize(0, 0);
        beta_beta.resize(0, 0);
        gamma_beta.resize(0, 0);
        sigma2k.resize(0);
        Vk.resize(0);
        Elogsigmak.resize(0);
        ElogVk.resize(0);
        sumElogVl.resize(0);
        pikexp1.resize(0);
        pikexp2.resize(0);
        index.resize(0);
        a_k.resize(0);
        b_k.resize(0);
        kappa_k.resize(0);
        lambda_k.resize(0);
        y_res.resize(0);
        bk.resize(0);
        eigen_alpha.resize(0);
}