/////4444


#ifndef __RUNDPRC_H__    
#define __RUNDPRC_H__


#include <ctime>
#include <cstdlib>//stdlib.h
#include <cstdio>
#include <cstring>
#include <cstddef>
#include "DPRC.h"
//#include "GEBV.h"
#include "group.h"
#include "ReadSNP.h"
#include "runDPRC.h"
#include "Eigen/Dense"

using namespace std;
using namespace Eigen;


int main(int argc, char ** argv);

#endif
