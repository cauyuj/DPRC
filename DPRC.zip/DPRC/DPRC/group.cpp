
// Created by yuj on 2021/1/29-6.

#include "ReadSNP.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <omp.h>
#include <cmath>

using namespace std;

int Group (long nID, long nSNP, double *markerMat){
    long GroupNumber1 = 0;
    long GroupNumber2 = 0;
    long GroupNumber3 = 0;   //初始化每个组的SNP数量；
    long GroupNumber4 = 0;

    ifstream groupFile (groupFile.c_str(), ifstream::in);
    if (!groupFile.is_open()){
        cout<<"error open groupFile file!"<<endl;
        exit(1);
    }
    string line;
    string SNPrs;
    string group;
    char * ch_ptr;
    while(getline(groupFile,line)){
        ch_ptr = strtok((char *)line.c_str(),"\t");
        SNPrs = ch_ptr;
        ch_ptr=strtok (NULL, " \t");
        group = ch_ptr;
        if (strcmp(group,"1") ==0){
            GroupNumber1++;
        }
        if (strcmp(group,"2") ==0){
            GroupNumber2++;
        }
        if (strcmp(group,"3") ==0){
            GroupNumber3++;
        }
        if (strcmp(group,"4") ==0){
            GroupNumber4++;
        }

    }
    long total;
    total = GroupNumber1 + GroupNumber2 + GroupNumber3 + GroupNumber4;
    if (total != nSNP){
        printf("Bad Group file, please check!\n");
    }

    long Class1[GroupNumber1];
    long Class2[GroupNumber2];
    long Class3[GroupNumber3];
    long Class4[GroupNumber4];


    long k_snp;
    long int1 =0;
    long int2 =0;
    long int3 =0;
    long int4 =0;

    while(getline(groupFile,line)){
        ch_ptr = strtok((char *)line.c_str(),"\t");
        SNPrs = ch_ptr;
        ch_ptr=strtok (NULL, " \t");
        group = ch_ptr;
        if (strcmp(group,"1") ==0){
            Class1[int1] = k_snp;
            int1++;
        }
        if (strcmp(group,"2") ==0){
            Class2[int2] = k_snp;
            int2++;
        }
        if (strcmp(group,"3") ==0){
            Class3[int3] = k_snp;
            int3++;
        }
        if (strcmp(group,"4") ==0){
            Class4[int4] = k_snp;
            int4++;
        }
        k_snp++;
    }

    long intT = int1 + int2 + int3 + int4;
    if (intT != nSNP){
        printf("Bad Group number, please check!\n");
    }
}