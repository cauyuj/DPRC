/////2222




#ifndef __GROUP_H__    
#define __GROUP_H__


#include "ReadSNP.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <omp.h>
#include <cmath>

using namespace std;

int Group (long nID, long nSNP, double *markerMat);

#endif
