////




#ifndef __DPRC_H__    
#define __DPRC_H__


#include <vector>

#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <cmath>
//#include <stdio.h>
//#include <stdlib.h>
#include <cstring>
#include <algorithm>

#include <gsl_permute.h>
#include <gsl_permutation.h>

#include "gsl_rng.h"
#include "gsl_linalg.h"
#include "gsl_blas.h"
#include "gsl_eigen.h"
#include "gsl_randist.h"
#include "gsl_cdf.h"
#include "gsl_roots.h"
#include "gsl_matrix.h"
#include "gsl_vector.h"
#include "Eigen/Dense"

using namespace std;
using namespace Eigen;

double sum_Elogvl2(const VectorXd vk, size_t k);
double sum_lambda_k(const MatrixXd pik_beta, size_t k, size_t n_k);
void DPRC (const MatrixXd X, const VectorXd Y, const MatrixXd W);
void DPRC_AS (const MatrixXd X, const VectorXd Y, const MatrixXd W);

#endif

