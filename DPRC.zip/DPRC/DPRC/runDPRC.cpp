
#define NUM_THREADS 5 //线程数
#include <ctime>
#include <cstdlib>//stdlib.h
#include <cstdio>
#include <cstring>
#include <cstddef>
#include "DPRC.h"
//#include "GEBV.h"
#include "group.h"
#include "ReadSNP.h"
#include "runDPRC.h"
#include "Eigen/Dense"

using namespace std;
using namespace Eigen;

int main(int argc, char ** argv){
    //check the number of parameter;
    if (argc != 7){
        printf("We need three parameters, please check!!\n");
        exit(1);
    }
    //read the parameters from the command line
    char bedFile[256];  //bed file;
    char outFile[200];  //out file;
    char method[200];   //sure which method was used
    char groupFile[200];//group file;
    char phenoFile[200];//pheno file;
    long i =0,j=0,a=0,b=0;
    for (i=0;i<5;i++){
        a = 2* i +1;
        b = 2* i +2;
        if (strcmp(argv[a],"--bfile")==0){
            strcpy(bedFile,argv[b]);
        }else if(strcmp(argv[a],"--OUT")==0){
            strcpy(outFile,argv[b]);
        }else if(strcmp(argv[a],"--GROUP")==0){
            strcpy(groupFile,argv[b]);
        }else if(strcmp(argv[a],"--Pheno")==0){
            strcpy(phenoFile,argv[b]);
        }else if(strcmp(argv[a],"--method")==0){
            strcpy(method,argv[b]);
        }else{
            printf("Unrecognized parameter for %s %s.\n",argv[a],argv[b]);
            exit(1);
        }
    }

    //Sure the number of individuals and SNPs, read the individuals' ID;
    long nID = 0, nSNP=0;
    char famFile[200];
    strcpy(famFile,bedFile);
    strcat(famFile,".fam");
    char temp[10000];

    FILE *inFam = fopen(famFile,"r");
    if (inFam == NULL){
        printf("Fail to open the plink fam file.\n");
        exit(1);
    }

    while(fgets(temp,10000,inFam)){
        nID++;
    }
    fclose(inFam);
    inFam =NULL;

    char **famInfo = (char**) calloc(nID,sizeof(char*));
    for(i=0;i< nID;i++){
        famInfo[i] = (char*) calloc(100,sizeof(char));
    }

    FILE *inFam1 = fopen(famFile,"r");
    if (inFam1 == NULL){
        printf("Fail to open the plink fam1 file.\n");
        exit(1);
    }

    i=0;
    while(fscanf(inFam1,"%*s%s%*[^\n]",famInfo[i]) ==1){
        i++;
    }
    fclose(inFam1);
    inFam1=NULL;

    char bimFile[200];
    strcpy(bimFile,bedFile);
    strcat(bimFile,".bim");
    FILE *inBim =fopen(bimFile,"r");
    if (inBim == NULL){
        printf("Fail to open the plink bim file.\n");
        exit(1);
    }

    while(fgets(temp,10000,inBim)){
        nSNP++;
    }
    fclose(inBim);
    inBim =NULL;

    printf("There are %ld individuals and %ld SNPs.\n",nID,nSNP);

    //read the plink bed file; marker matrix;
    printf("Read the plink bed file.\n");
    double *markerMat = (double *) calloc(nID*nSNP,sizeof(double));
    if (markerMat == NULL){
        printf("Not enough memory for marker matrix.\n");
        exit(1);
    }

    double missing = -5.0;
    readBed(bedFile,nID,nSNP,markerMat,missing);

    //构建各个矩阵X,Y,W
    long k =0;
    MatrixXd X = MatrixXd::Zero(nID,nSNP);
    for (size_t i=0;i<nSNP;i++){
        for(size_t j=0;j<nID;j++){
            X(j,i) = markerMat[k];
            k++;
        }
    }

    //构建Y向量；
    VectorXd Y(nID);
    size_t l = 0;
    char *p;
    int p1 = 0;
    while(fgets(temp,10000,inFam)){
        p = strtok(temp, " ");//是temp，还是*temp？
        while( p != NULL ){
            p1+=1;
            if (p1 == 6){
                Y(l) = double atof(const char *p);
                l++;
            }
            //读取下一个p
            p = strtok(NULL, "  ");
        }
    }

    ////构建W向量；
    VectorXd W(nID);
    for (int r= 0;r < nID;r++){
        W[r] =1;
    }


    Group(long nID, long nSNP, double *markerMat)；

    //开始抽样
    if (strcmp(method,"1") == 0){
        DPRC(X,Y,W);
    }
    else if(strcmp(method,"2") == 0){
        DPRC_AS(X,Y,W);
    }
    free(markerMat);
    markerMat = NULL;

}