//
// Created by yuj on 2021/1/28-3.
//

#include "ReadSNP.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <omp.h>
#include <cmath>


double toCode(unsigned char temp, long m, double missing, unsigned char geno[4][4]);
int readBed(unsigned char *bedFile, long nID, long nSNP, double *markerMat, double missing){
    //open the bed file
    char inFile[128];
    strcpy(inFile,bedFile);
    strcat(inFile,".bed");
    FILE *inBed =fopen(inFile,"r");
    if (inBed == NULL){
        printf("Fail to open the plink bed file.\n");
        exit(1);
    }

    //define the mask for each genotype
    unsigned char geno[4][4];// 4 SNPs, 4 likely genotypes;
    //Homozygous    //Missing genotype  //heterozygous   //Homozygous
    geno[0][0] = '0' - 48; geno[0][1] = '1' - 48;
    geno[0][2] = '2' - 48; geno[0][3] = '3' - 48;

    geno[1][0] = geno[0][0] << 2; geno[1][1] = geno[0][1] << 2;
    geno[1][2] = geno[0][2] << 2; geno[1][3] = geno[0][3] << 2;

    geno[2][0] = geno[0][0] << 4; geno[2][1] = geno[0][1] << 4;
    geno[2][2] = geno[0][2] << 4; geno[2][3] = geno[0][3] << 4;

    geno[3][0] = geno[0][0] << 6; geno[3][1] = geno[0][1] << 6;
    geno[3][2] = geno[0][2] << 6; geno[3][3] = geno[0][3] << 6;

    //read the bed file
    long nBlock = nID/4; //the number of block (total -1) for each SNP;
    long nExtraSNP = nID % 4; //SNP number in last block;
    if (nExtraSNP ==0){
        nExtraSNP =4;
        nBlock = nBlock -1;
    }
    long i=0, j=0, k=0, m=0;
    unsigned char temp;
    for (i=0; i< 3;i++){
        if (fread(&temp,sizeof(char),1,inBed)==1){
            printf("The %ld th byte in bed file is: %c %d.\n",i,temp,temp);
        }
        else{
            printf("Fail to read the first three bytes in bed file.\n");
            exit(1);
        }
    }
    for (i=0;i<nSNP;i++){
        for (j=0;j<nBlock;j++){
            if (fread(&temp,sizeof(char),1,inBed) !=1){
                printf("Fail to read thr bed file, please check.\n");
                printf("%ld\t%ld\n",i,j);
                exit(1);
            }
            for (m=0;m<4;m++) {
                markerMat[k] = toCode(temp, m, missing, geno);
                k++;
                if (k > nID * nSNP) {
                    printf("Bad plink bed file,please check.\n");
                    exit(1);
                }
            }
        }

        //Read last block;
        if(fread(&temp,sizeof(char),1,inBed) != 1){
            printf("Fail to read the bed file, please check.\n");
            printf("%ld\t%ld\n",i,j);
            exit(1);
        }
        for(m = 0; m < nExtraSNP; m++){
            markerMat[k] = toCode(temp, m, missing, geno);
            k++;
            if(k > nID*nSNP){
                printf("Bad plink bed file, please check.\n");
                exit(1);
            }
        }
    }
    fclose(inBed);
    inBed =NULL;
    return 1;
}

// code 0,1,2 and missing for genotype
double toCode(unsigned char temp, long m, double missing, unsigned char geno[4][4]){
    double codeValue =1000;
    unsigned int a = (unsigned int)(geno[m][0] & temp);
    unsigned int b = (unsigned int)(geno[m][1] & temp);
    unsigned int c = (unsigned int)(geno[m][2] & temp);
    unsigned int d = (unsigned int)(geno[m][3] & temp);

    if (a==0){
        codeValue = 0;
    }
    if (b==1 || b==4 || b==16 || b==64){
        codeValue = missing;
    }
    if (c==2 || c==8 || c==32 || c==128){
        codeValue = 1;
    }
    if (d==3 || d==12 || d==48 || d==192){
        codeValue = 2;
    }
    if (codeValue + 5 < 0.01){
        printf("Missing genotype need to be imputed in this program.\n");
        exit(1);
    }
    if (1000 - codeValue < 0.01){
        printf("Unrecognized character in plink bed file.\n");
        exit(1);
    }
    return codeValue;
}
